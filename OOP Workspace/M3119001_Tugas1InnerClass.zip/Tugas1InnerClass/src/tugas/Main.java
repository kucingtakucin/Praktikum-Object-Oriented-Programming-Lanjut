package tugas;

public class Main {
	
	public static void main(String[] args) {
		InnerUkuran innerUkuran = new InnerUkuran();
		innerUkuran.getHasilUkuran();
		innerUkuran.getHasilSuhu();
	}
}
