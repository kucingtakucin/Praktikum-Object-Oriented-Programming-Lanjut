package vokasi.d3ti.interinner;

public class Suhu implements TransformasiSuhu {

	@Override
	public double CelsioustoFahrenheit(double celsius) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double CelsioustoReamur(double celsius) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double FahrenheittoCelsious(double fahrenheit) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double FahrenheittoReamur(double fahrenheit) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double ReamurtoCelsious(double reamur) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double ReamurtoFahrenheit(double reamur) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
