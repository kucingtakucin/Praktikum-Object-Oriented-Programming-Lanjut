module tugas1InnerClass {
}