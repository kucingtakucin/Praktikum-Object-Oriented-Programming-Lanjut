module tugas4Applet {
	requires java.desktop;
}